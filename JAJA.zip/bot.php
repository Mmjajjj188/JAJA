<?php
date_default_timezone_set('Asia/Baghdad');



if(isset($update->callback_query)) {
          $chatiId = $update->callback_query->message->chat->id;
   
}

$ban = explode("\n",file_get_contents("ban.txt"));
/*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

if (!file_exists("token")) {
 $gii = readline("token  : ");
 file_put_contents("token",$gii);

}
if (!file_exists("ID")) {
 $gii = readline("ID  : ");
 file_put_contents("ID",$gii);

}
if(!file_exists('config.json')){
	$token = file_get_contents('token');
	$id = file_get_contents('ID');
	file_put_contents('config.json', json_encode(['id'=>$id,'token'=>$token]));
	
}
$token = file_get_contents('token');
	$id = file_get_contents('ID');
	

  $config = json_decode(file_get_contents('config.json'),1);
if(!file_exists('accounts.json')){
    file_put_contents('accounts.json',json_encode([]));
}
include 'index.php';
try {
	$callback = function ($update, $bot) {
		global $id;
		if($update != null){
		  $config = json_decode(file_get_contents('config.json'),1);
		  $config['filter'] = $config['filter'] != null ? $config['filter'] : 1;
      $accounts = json_decode(file_get_contents('accounts.json'),1);
		if(isset($update->message)){
				$message = $update->message;
				$chatId = $message->chat->id;
				$text = $message->text;
				$Akilbot = file_get_contents('bots');
				$from_id = $message->from->id;
				$fn = $message->from->first_name;
				$token = file_get_contents('token');
				$akilid = explode("\n",file_get_contents("ids.txt"));
			    $akilids = count($akilid)-1;
				$username = $message->from->username;
				$token = $config['token'];
				$Spe = file_get_contents("https://api.telegram.org/bot  توكن/getChatMember?chat_id=@AEETCHI&user_id=$chatId");
				$Spe2 = file_get_contents("https://api.telegram.org/bot توكن/getChatMember?chat_id=@akil828&user_id=$chatId");
				$url_info = file_get_contents("https://api.telegram.org/bot$token/getMe");
				$json_info = json_decode($url_info);
				$userr = $json_info->result->username;
				$ban = explode("\n",file_get_contents("ban.txt"));
				$rmdon = file_get_contents("$chatId/akil828");
				if( $rmdon == "on1" and $text  != "/start"){
						

	
           $url_info2 = file_get_contents("https://api.telegram.org/bot$text/getMe");
				$json_info2 = json_decode($url_info2);

				$usjjjerr = $json_info2->result->username;
				
				if($usjjjerr == null){
                 $bot->sendMessage([
                 'chat_id'=>$chatId,
                  'text'=>"توكن خطاء",
                   

                ]);
                
                
                /*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

      }elseif(file_exists("$from_id/1") or file_exists("$from_id/2")){
          $bot->sendMessage([
                 'chat_id'=>$chatId,
                  'text'=>"يمكن صنع بوت 1 فقط",
                  
                  ]);
      }else{

       mkdir("$from_id/1");       
      usleep(400000);
      system("cp -r  akilx.zip $from_id/1 ");
      system("cd $from_id/1 ; unzip akilx.zip  ");
      usleep(400000);
      system("cd ..");
      system("cd ..");
      file_put_contents("$from_id/1/ID","$from_id");
      file_put_contents("$from_id/1/token","$text");
      system("cd $from_id ; cd 1 ; screen -dmS n$from_id php bot.php");
      $bot->sendMessage([
                 'chat_id'=>$chatId,
                  'text'=>"تم صنع البوت",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'دخول البوت','url'=>"https://t.me/$usjjjerr"]],
                    
                      ]
                  ])
              ]);
              file_put_contents("$from_id/akil828","off");
                   $bot->sendMessage([
                 'chat_id'=>$id,
                  'text'=>"٭ تم صنع بوت جديد في الصانع الخاص بك 📝
            -----------------------
• معلومات الشخص الذي صنع البوت .

• الاسم : $fn  ،
• المعرف : @$username ،
• الايدي : $from_id ،
            -----------------------
• التوكن  : $text  ،
• معرف البوت المصنوع : @$usjjjerr ،
            -----------------------
            النوع متاحات

• عدد البوتات المصنوعة : $Akilbot",
                   'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'الغاء التفعيل','callback_data'=>'rmmmrm']],
                    
                      ]
                  ])
              ]);
                  
                 
                  }
			}
			
			/*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

			
			
			
			
			if( $rmdon == "on2" and $text  != "/start"){
						

	
           $url_info2 = file_get_contents("https://api.telegram.org/bot$text/getMe");
				$json_info2 = json_decode($url_info2);

				$usjjjerr = $json_info2->result->username;
				
				if($usjjjerr == null){
                 $bot->sendMessage([
                 'chat_id'=>$chatId,
                  'text'=>"توكن خطاء",
                   

                ]);
      }elseif(file_exists("$from_id/1") or file_exists("$from_id/2")){
          $bot->sendMessage([
                 'chat_id'=>$chatId,
                  'text'=>"يمكن صنع بوت 1 فقط",
                  
                  ]);
      }else{

       mkdir("$from_id/2");       
      usleep(400000);
      system("cp -r  v.zip $from_id/2 ");
      system("cd $from_id/2 ; unzip v.zip  ");
      usleep(400000);
      system("cd ..");
      system("cd ..");
      file_put_contents("$from_id/2/ID","$from_id");
      file_put_contents("$from_id/2/token","$text");
      system("cd $from_id ; cd 2 ; screen -dmS n$from_id php bot.php");
      $bot->sendMessage([
                 'chat_id'=>$chatId,
                  'text'=>"تم صنع البوت",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'دخول البوت','url'=>"https://t.me/$usjjjerr"]],
                    
                      ]
                  ])
              ]);
              file_put_contents("$from_id/E8E8EEE","off");
                   $bot->sendMessage([
                 'chat_id'=>$id,
                  'text'=>"٭ تم صنع بوت جديد في الصانع الخاص بك 📝
            -----------------------
• معلومات الشخص الذي صنع البوت .

• الاسم : $fn  ،
• المعرف : @$username ،
• الايدي : $from_id ،
            -----------------------
• التوكن  : $text  ،
• معرف البوت المصنوع : @$usjjjerr ،
            -----------------------
            النوع تشيكر

• عدد البوتات المصنوعة : $Akilbot",
                   'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'الغاء التفعيل','callback_data'=>'rmmmrm']],
                    
                      ]
                  ])
              ]);
                  
                 
                  }
			}
			
			
			
			
			
			/*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

			
			
			
			
			
			
			
			
			
				if($chatId == $id){
				
				
		if(strpos($text,"/ak")!==false and $chatId == $id){
	$akilid = explode("\n",file_get_contents("ids.txt"));
			
$bhb = explode('/ak ',$text)[1];

            $akilids = count($akilid)-1;
         
       for($x2=0;$x2<count($akilid); $x2++){
  $bot->sendMessage([
'chat_id'=>$akilid[$x2],
'text'=>$bhb,
					]);}
  $bot->sendMessage([
'chat_id'=>$id,
'text'=>"تم ارسال ارساله الي $akilids عضو",
		]);
}
				
				if(strpos($text,"حظر")!==false and $chatId == $id){
	
			
$bhb1 = explode('حظر ',$text)[1];
          file_put_contents("ban.txt",$bhb1."\n",FILE_APPEND);
          system("screen -S n$bhb1 -X kill");
  $bot->sendMessage([
'chat_id'=>$id,
'text'=>"تم حظر $bhb1",
		]);
		$ban = explode("\n",file_get_contents("ban.txt"));
		$bot->sendMessage([
'chat_id'=>$bhb1,
'text'=>"تم حظرك ",
		]);
}
				
					($text == '/start'){
              $bot->sendphoto([ 'chat_id'=>$chatId,
              'photo'=>"https://t.me/ex111/4",
                   'caption'=>'𝑊𝐸𝐿𝐶𝑂𝑀𝐸 𝑇𝑂 𝐻𝐸𝐿𝐿 𝐻𝑈𝑁𝑇𝐸𝑅 †
~ @ZZZNZN 🍂',
                  'inline_keyboard'=>true,
                  'reply_markup'=>json_encode([
                         'keyboard'=>[
                          [['text'=>'- English 🇺🇸']],
                          [['text'=>'- عربي 🇮🇶']],
                          [['text'=>'- فيديو شرح للبوت 📷']],
                          [['text'=>'- طرق الصيد 📻']],
                          [['text'=>'- 𝑴𝑼𝑺𝑻𝑨𝑭𝑨 𝑯𝑼𝑵𝑻𝑬𝑹℡ ̇༗']],
                          [['text'=>'️ما هوا بوت صيد والمتاحات 🔥']],
                          [['text'=>'️- فيديو تخطي حظر وهمي الانستقرام 🎥']],
                          [['text'=>'️- فيديو طريقه توصيل الريست 🗡️']],
                          [['text'=>'️تطبيق توصيل الريست✝️']],
                      ]
                  ])
              ]);   
            } if($text == '- English 🇺🇸'){ 
        	$config['filter'] = $text;
		    $bot->sendMessage([
		       'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"𝙷𝙸 𝙱𝚁𝙾 𝙸𝙽 𝚃𝙷𝙴 𝙲𝙾𝙽𝚃𝚁𝙾𝙻 𝙱𝚈 ~ @ZZZNZN",
                'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'✨┇ Add Accounts🛗','callback_data'=>'login']],
                          [['text'=>'🕵️┇ Geting users','callback_data'=>'grabber']],
                          [['text'=>'📳┇ Start Checking','callback_data'=>'run'],['text'=>' 📴┇Stop Checking','callback_data'=>'stop']],
                          [['text'=>'🪐┇Accounts Status','callback_data'=>'status']],
                      ]
                  ])
               ]);
           } if($text == '- عربي 🇮🇶'){
            $config['filter'] = $text;
		    $bot->sendMessage([
		       'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"𝙷𝙸 𝙱𝚁𝙾 𝙸𝙽 𝚃𝙷𝙴 𝙲𝙾𝙽𝚃𝚁𝙾𝙻 𝙱𝚈 ~ @ZZZNZN",
                'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'تسجيل حساب ✨┇','callback_data'=>'login']],
                          [['text'=>'طرق الصيد 🕵️┇','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 📳┇','callback_data'=>'run'],['text'=>'ايقاف الصيد 📴┇','callback_data'=>'stop']],
                          [['text'=>' حاله الحسابات 🪐┇','callback_data'=>'status']],
                      ]
                  ])
               ]);
               
               } if($text == '- فيديو شرح للبوت 📷'){
                  $bot->sendvideo([ 
                  'chat_id'=>$chatId,
                  'video'=>"https://t.me/SUPERX1/50",

              ]);   
                
               } if($text == '- طرق الصيد 📻'){
                 $bot->sendvoice([
                  'chat_id'=>$chatId,
                  'voice'=>"https://t.me/FOLLOW_NAFSEA/147",
                  
              ]);   
                
              } if($text == '- طرق الصيد 📻'){
                $bot->sendvoice([ 
                 'chat_id'=>$chatId,
                 'voice'=>"https://t.me/FOLLOW_NAFSEA/160",

              ]);   
                
           } if($text == '- 𝑴𝑼𝑺𝑻𝑨𝑭𝑨 𝑯𝑼𝑵𝑻𝑬𝑹℡ ̇༗'){ 
            $bot->sendMessage([
		       'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>".𖡃. 𝐂𝐡 :- l @E8E8EEE
𝐓𝐞𝐥𝐞 : @ZZZNZN |",

              ]);   
              
           } if($text == '️- ما هوا بوت صيد والمتاحات 🔥'){ 
            $bot->sendMessage([
         'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"قبل ان اعلمك كيف تقوم بصيد المتاحات يجب عليك ان تعرف ما هي المتاحات
*
*
*
- المتاحات هي : حسابات انستقرام او فيس بوك او تويتر او .......  هذه الحسابات تكون مربوط بايميلات لكن هذه الايميلات غير موجود
*
*
*
كيف تربط الايميلات بهذه الحسابات اذ لم تكن موجودة اصلن . تربط هذه الايميلات بالحسابات لاكن عند ربطها لا تقوم بطلب كود للتحقق من البريد

*
*
*
- طريقة عمل بوت الصيد

طريقة عمل بوت الصيد هيه انك تقوم بجمع يوزرات من الانستقرام ووضعها بالبوت ويقوم بالتخمين على المتابعين او الذين يقوم بمتابعتهم حسب اختيار بالطبع هناك طرق اخرى للسحب عبر هاشتاق متلا او كلمات بالبحث
",

              ]);
              
           } if($text == '️- فيديو تخطي حظر وهمي الانستقرام 🎥'){
                  $bot->sendvideo([ 
                  'chat_id'=>$chatId,                  'video'=>"https://t.me/SUPERX1/8",

              ]);
              
              } if($text == '️- فيديو طريقه توصيل الريست 🗡️'){
                  $bot->sendvideo([ 
                  'chat_id'=>$chatId,                  'video'=>"https://t.me/HH7H9/7146",
				  'caption'=>'برنامج توصيل الريست 🌝
https://t.me/a011437/6',
              ]);
              
          } elseif($text != null){
          	if($config['mode'] != null){
          		$mode = $config['mode'];
          		if($mode == 'addL'){
          			$ig = new ig(['file'=>'','account'=>['useragent'=>'Instagram 27.0.0.7.97 Android (23/6.0.1; 640dpi; 1440x2392; LGE/lge; RS988; h1; h1; en_US)']]);
          			list($user,$pass) = explode(':',$text);
          			list($headers,$body) = $ig->login($user,$pass);
          			// echo $body;
          			$body = json_decode($body);
          			if(isset($body->message)){
          				if($body->message == 'challenge_required'){
          					$bot->sendMessage([
          							'chat_id'=>$chatId,
          							'parse_mode'=>'markdown',
          							'text'=>"*Error*. \n - Challenge Required"
          					]);
          				} else {
          					$bot->sendMessage([
          							'chat_id'=>$chatId,
          							'parse_mode'=>'markdown',
          							'text'=>"*Error*.\n - Incorrect Username Or Password"
          					]);
                  
                  
                  
                  
                  /*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

          		    $config['mode'] = null;
		              $config['mid'] = null;
		              file_put_contents('config.json', json_encode($config));
          		  } else {
          		    bot('sendMessage',[
          		        'chat_id'=>$chatId,
          		        'text'=>'- يرجى ارسال رقم فقط .'
          		    ]);
          		  }
          		} else {
          		  switch($config['mode']){
          		    case 'search':
          		      $config['mode'] = null;
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php search.php');
          		      break;
          		      case 'followers':
          		      $config['mode'] = null;
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php followers.php');
          		      break;
          		      
          		      
          		      
          		      /*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

          		      case 'following':
          		      $config['mode'] = null;
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php following.php');
          		      break;
          		      case 'hashtag':
          		      $config['mode'] = null;
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php hashtag.php');
          		      break;
          		  }
          		}
          	}
          }
				} else {
				$token = file_get_contents('token');
				$Spe = file_get_contents("https://api.telegram.org/bot توكن /getChatMember?chat_id=@AEETCHI&user_id=$chatId");
				$Spe2 = file_get_contents("https://api.telegram.org/bot توكن/getChatMember?chat_id=@akil828&user_id=$chatId");
   if($text && (strpos($Spe,'"status":"left"') or strpos($Spe,'"Bad Request: USER_ID_INVALID"') or strpos($Spe,'"status":"kicked"') or strpos($Spe2,'"status":"left"') or strpos($Spe2,'"Bad Request: USER_ID_INVALID"') or strpos($Spe2,'"status":"kicked"'))!== false){
$bot->sendMessage([
'chat_id'=>$chatId,
'text'=>"- عذرا عزيزي يجب عليك الاشتراك في قنوات البوت اولا
@E8E8EEE
@E8E8EEE
",
]);
	          }elseif($text == "/start" and $chatId != $id and !in_array($chatId, $ban)) {
	          mkdir("$chatId");
				$akilid = explode("\n",file_get_contents("ids.txt"));
				if(!in_array($chatId, $akilid) and !in_array($chatId, $ban)){
                file_put_contents("ids.txt", $chatId."\n",FILE_APPEND);
                                              $bot->sendMessage([
		                			'chat_id'=>$chatId,
	 
                					'text'=>"اهلا في بوت مصنع بوتات الصيد",
	 
              					'reply_markup'=>json_encode([
        
                	          'inline_keyboard'=>[
  					                   [['text'=>'صنع بوت','callback_data'=>'maker'],['text'=>'حذف بوت','callback_data'=>'dletr']],
			                              [['text'=>'معلومات','callback_data'=>'akilm']]          
                			       ] 
	   	])
			]);
                			       
                			       
                			       $bot->sendMessage([
                 'chat_id'=>$id,
                  'text'=>"٭ تم دخول شخص جديد الى البوت الخاص بك 👾
            -----------------------
• معلومات العضو الجديد .

• الاسم :  $fn
• المعرف : @$username 
• الايدي : $from_id
            -----------------------
• عدد الاعضاء الكلي : $akilids",
                  
                  ]);
                			       
                }elseif($text == "/start" or $data == "hbauuck1" and $chatId != $id and !in_array($chatId, $ban)){
			
               
                
                              $bot->sendMessage([
		                			'chat_id'=>$chatId,
	 
                					'text'=>"اهلا في بوت مصنع بوتات الصيد",
	 
              					'reply_markup'=>json_encode([
        
                	          'inline_keyboard'=>[
  					                   [['text'=>'صنع بوت','callback_data'=>'maker'],['text'=>'حذف بوت','callback_data'=>'dletr']],
			                              [['text'=>'معلومات','callback_data'=>'akilm'],['text'=>'طريقه التفعيل','callback_data'=>'djjfbfbbd']],           
                			       ] 
	   	])
			]);
	    	
				
								
					
					
					}
				
				
                      }
					
				}
				
				
				/*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

				
				
			} elseif(isset($update->callback_query)) {
          $chatId = $update->callback_query->message->chat->id;
          $mid = $update->callback_query->message->message_id;
          $ban = explode("\n",file_get_contents("ban.txt"));
          $data = $update->callback_query->data;
          echo $data;
          
          
 
                           
          if($data == 'login'){

        		$keyboard = ['inline_keyboard'=>[
									[['text'=>"ضيف وهمي جديد ➕",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"تسجيل الخروج",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']];
		              $bot->sendMessage([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                   'text'=>"اهلا عزيزي ✔️ في الاسفل هي حساباتك الوهميه المسجله في الاداة",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
		              /*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

		              
		   } elseif($data == 'thkm'){
		              $bot->editMessageText([
                 'chat_id'=>$chatId,
                    'message_id'=>$mid,
                  'text'=>" اختار نوع البوت",                 
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>'اذاعه ','callback_data'=>'dhhdjd'],['text'=>'الاحصائيات','callback_data'=>'jdjdjjj']],
                      [['text'=>'تشيكر يوزرات','callback_data'=>'hhhuu7y']],
                                ]
                                ])
                                ]);
		              } elseif($data == 'dletr'){
		                    if(!file_exists("$chatId/1") or !file_exists("$chatId/2")){
                $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"قم بصنع بوت اولا",
							'show_alert'=>1
						]);
                  }elseif(file_exists("$chatId/1") or file_exists("$chatId/2")){
		              system("rm -rf $chatId/1");
		              system("rm -rf $chatId/2");
		              system("screen -S n$chatId -X kill");
		                  $bot->sendMessage([
                 'chat_id'=>$chatId,
                  'text'=>"تم حذف البوت",
                  ]);
		              $bot->sendMessage([
                 'chat_id'=>$id,
                  'text'=>"حذف بوته : $chatId",
                  ]);
		              }
		               } elseif($data == 'hback1'){
		              
		              $bot->editMessageText([
                 'chat_id'=>$chatId,
                    'message_id'=>$mid,
                    
	 
                					'text'=>"اهلا في بوت مصنع بوتات الصيد",
	 
              					'reply_markup'=>json_encode([
        
                	          'inline_keyboard'=>[
  					                   [['text'=>'صنع بوت','callback_data'=>'maker'],['text'=>'حذف بوت','callback_data'=>'dletr']],
			                              [['text'=>'معلومات','callback_data'=>'akilm'],['text'=>'طريقه التفعيل','callback_data'=>'djjfbfbbd']],           
                			       ] 
	   	])
			]);
		              	
 } elseif($data == 'djjfbfbbd'){



/*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/



		              $bot->sendMessage([
                 'chat_id'=>$chatId,
                  'text'=>"https://t.me/akil828/3189",
                  ]);
		              
		              
		              } elseif($data == 'maker' and !in_array($chatId,$ban)){
		              mkdir("$chatId");
		              file_put_contents("$chatId/akil828","on1");
		              
		                  $bot->editMessageText([
                 'chat_id'=>$chatId,
                    'message_id'=>$mid,
                  'text'=>" اختار نوع البوت",                 
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                      
                      [['text'=>'صيد متاحات','callback_data'=>'maker1']],
                      [['text'=>'تشيكر يوزرات','callback_data'=>'maker2']],
                                      [['text'=>'رجوع','callback_data'=>'hback']],
                                      ]
                                      ])
                  ]);
                  file_put_contents("$chatId/akil828","on1");
		} elseif($data == 'akilm'){
		  
		  
		  
		                       
          
     $bot->sendMessage([
                      'chat_id'=>$chatId,
                      
                      'text'=>"معلومات البوت 
                      بوت مجاني
                      لشراء ملف البوت تواصل معاء المطور @FFFFFFM 
                      قناتي : @AKIL828",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                                      [['text'=>'رجوع','callback_data'=>'hback1']],
                           
 ]
                  ])
              ]);
				
		/*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

		              } elseif($data == 'maker2' and !in_array($chatId, $ban)){
		
		$bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"خربان اصنع بوت غير",
							'show_alert'=>1
						]);
		
                  
		} elseif($data == 'maker1' and !in_array($chatId, $ban)){
		
		
		file_put_contents("$chatId/akil828","on1");
                
                    $bot->editMessageText([
                 'chat_id'=>$chatId,
                    'message_id'=>$mid,
                  'text'=>"قم بارسال التوكن ",
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                                      [['text'=>'رجوع','callback_data'=>'hback1']],
                                      ]
                                      ])
                  ]);
                  file_put_contents("$chatId/akil828","on1");
		/*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

		              
		                  } elseif($data == 'hback' and !in_array($chatId, $ban)){
          	file_put_contents("$from_id/1/akil828","off");
             $bot->editMessageText([
		                			'chat_id'=>$chatId,
		         		                      'message_id'=>$mid,
	 
                					'text'=>"اهلا في بوت مصنع بوتات الصيد",
	 
              					'reply_markup'=>json_encode([
        
                	          'inline_keyboard'=>[
  					                   [['text'=>'صنع بوت','callback_data'=>'maker'],['text'=>'حذف بوت','callback_data'=>'dletr']],
			                              [['text'=>'معلومات','callback_data'=>'akilm'],['text'=>'طريقه التفعيل','callback_data'=>'djjfbfbbd']],           
                			       ] 
	   	])
			]);
				
								

		              
		              
		              
		              
		              /*

ملفي عقيل @FFFFFFM

مجاني

قناتي : @Akil828

كس ام الي يغير الحقوق او يبيع الملف 
اذا امك قحبه غير حرف من الحقوق
واذ ترضا على على نفسك غير

*/

		              
		              
		              
		              
          } elseif($text != null){
          	if($config['mode'] != null){
          		$mode = $config['mode'];
          		if($mode == 'addL'){
          			$ig = new ig(['file'=>'','account'=>['useragent'=>'Instagram 27.0.0.7.97 Android (23/6.0.1; 640dpi; 1440x2392; LGE/lge; RS988; h1; h1; en_US)']]);
          			list($user,$pass) = explode(':',$text);
          			list($headers,$body) = $ig->login($user,$pass);
          			// echo $body;
          			$body = json_decode($body);
          			if(isset($body->message)){
          				if($body->message == 'challenge_required'){
          					$bot->sendMessage([
          							'chat_id'=>$chatId,
          							'parse_mode'=>'markdown',
          							'text'=>"*Error*. \n - Challenge Required"
          					]);
          				} else {
          					$bot->sendMessage([
          							'chat_id'=>$chatId,
          							'parse_mode'=>'markdown',
          							'text'=>"*Error*.\n - Incorrect Username Or Password"
          					]);
          				}
          			} elseif(isset($body->logged_in_user)) {
          				$body = $body->logged_in_user;
          				preg_match_all('/^Set-Cookie:\s*([^;]*)/mi', $headers, $matches);
								  $CookieStr = "";
								  foreach($matches[1] as $item) {
								      $CookieStr .= $item."; ";
								  }
          				$account = ['cookies'=>$CookieStr,'useragent'=>'Instagram 27.0.0.7.97 Android (23/6.0.1; 640dpi; 1440x2392; LGE/lge; RS988; h1; h1; en_US)'];
          				
          				$accounts[$text] = $account;
          				file_put_contents('accounts.json', json_encode($accounts));
          				$mid = $config['mid'];
          				$bot->sendMessage([
          				      'parse_mode'=>'markdown',
          							'chat_id'=>$chatId,
          							'text'=>"*Done Add New Accounts To Your Tool.*\n _Username_ : [$user])(instagram.com/$user)\n_Account Name_ : _{$body->full_name}_",
												'reply_to_message_id'=>$mid		
          					]);
          				$keyboard = ['inline_keyboard'=>[
										[['text'=>"Add New Accounts",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"Logout",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'🔙 رجوع','callback_data'=>'back']];
		              $bot->editMessageText([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                  'text'=>"Accounts Control Page.",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
		              $config['mode'] = null;
		              $config['mid'] = null;
		              file_put_contents('config.json', json_encode($config));
          			}
          		}  elseif($mode == 'selectFollowers'){
          		  if(is_numeric($text)){
          		    bot('sendMessage',[
          		        'chat_id'=>$chatId,
          		        'text'=>"تم التعديل.",
          		        'reply_to_message_id'=>$config['mid']
          		    ]);
          		    $config['filter'] = $text;
          		    $bot->editMessageText([
                      'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"𝙷𝙸 𝙱𝚁𝙾 𝙸𝙽 𝚃𝙷𝙴 𝙲𝙾𝙽𝚃𝚁𝙾𝙻 𝙱𝚈 ~ @ZZZNZN",
                'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'تسجيل حساب ✨┇','callback_data'=>'login']],
                          [['text'=>'طرق الصيد 🕵️┇','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 📳┇','callback_data'=>'run'],['text'=>'ايقاف الصيد 📴┇','callback_data'=>'stop']],
                          [['text'=>' حاله الحسابات 🪐┇','callback_data'=>'status']],
                      ]
                  ])
               ]);
          		    $config['mode'] = null;
		              $config['mid'] = null;
		              file_put_contents('config.json', json_encode($config));
          		  } else {
          		    bot('sendMessage',[
          		        'chat_id'=>$chatId,
          		        'text'=>'- يرجى ارسال رقم فقط .'
          		    ]);
          		  }
          		} else {
          		  switch($config['mode']){
          		    case 'search': 
          		      $config['mode'] = null; 
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php search.php');
          		      break;
          		      case 'followers': 
          		      $config['mode'] = null; 
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php followers.php');
          		      break;
          		      case 'following': 
          		      $config['mode'] = null; 
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php following.php');
          		      break;
          		      case 'hashtag': 
          		      $config['mode'] = null; 
          		      $config['words'] = $text;
          		      file_put_contents('config.json', json_encode($config));
          		      exec('screen -dmS gr php hashtag.php');
          		      break;
          		  }
          		}
          	}
          }
				} else {
					$bot->sendvideo([
       'chat_id'=>$chatId,
       'video'=> "https://t.me/a011437/3",
        'caption'=>'البوت مدفوع 💲 و ليس مجاني 👁‍🗨
لشراء نسخه مراسلة المطور 👁‍🗨',
                  'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'▫️| مطور البوت','url'=>'t.me/ZZZNZN']],
                       [['text'=>"▪️| قناه صيد المشتركين", 'url'=>"t.me/E8E8EEE"]],
                  ]
							])
					]);
				}
			} elseif(isset($update->callback_query)) {
          $chatId = $update->callback_query->message->chat->id;
          $mid = $update->callback_query->message->message_id;
          $data = $update->callback_query->data;
          echo $data;
          if($data == 'login'){
              
        		$keyboard = ['inline_keyboard'=>[
										[['text'=>"Add New Accounts",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"Logout",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'🔙 رجوع','callback_data'=>'back']];
		              $bot->editMessageText([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                  'text'=>"Accounts Control Page.",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
          } elseif($data == 'addL'){
          	
          	$config['mode'] = 'addL';
          	$config['mid'] = $mid;
          	file_put_contents('config.json', json_encode($config));
          	$bot->sendMessage([
          			'chat_id'=>$chatId,
          			'text'=>"Send Account Like : \n `user:pass`",
          			'parse_mode'=>'markdown'
          	]);
          } elseif($data == 'grabber'){
            
            $for = $config['for'] != null ? $config['for'] : 'حدد الحساب';
            $count = count(explode("\n", file_get_contents($for)));
            $bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                        [['text'=>'🔎 سحب من البحث','callback_data'=>'search']],
                        [['text'=>'#⃣ سحب من الهشتاكات','callback_data'=>'hashtag'],['text'=>'📮 سحب من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'👤 سحب من المتابعين','callback_data'=>'followers'],['text'=>"🚹 سحب من المتابعهم",'callback_data'=>'following']],
                        [['text'=>"تحديد حساب ♾ : $for",'callback_data'=>'for']],
                        [['text'=>'🔖 لسته جديده','callback_data'=>'newList'],['text'=>'🖇 لسته قديمة','callback_data'=>'append']],
                        [['text'=>'✅ رجوع','callback_data'=>'back']],
                    ]
                ])
            ]);
          } elseif($data == 'search'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان ارسل كلمات البحث لتم فحصهم \n يمكنك ارسال اكثر من كلمه من خلال وضع مسافه بينهم"
            ]);
            $config['mode'] = 'search';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'followers'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان ارسل اليوزر لتم فحص اليتابعهم \n يمكنك ارسال اكثر من يوزر من خلال وضع مسافه بينهم"
            ]);
            $config['mode'] = 'followers';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'following'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان ارسل اليوزر لتم فحص المتابعين \n يمكنك ارسال اكثر من يوزر من خلال وضع مسافه بينهم"
            ]);
            $config['mode'] = 'following';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'hashtag'){
            $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"الان ارسل الهشتاكات بدون العلامه # \nيمكنك ارسال هشتاك واحد"
            ]);
            $config['mode'] = 'hashtag';
            file_put_contents('config.json', json_encode($config));
          } elseif($data == 'newList'){
            file_put_contents('a','new');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Done Select New List.",
							'show_alert'=>1
						]);
          } elseif($data == 'append'){ 
            file_put_contents('a', 'ap');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Done Select Exsist list.",
							'show_alert'=>1
						]);
						
          } elseif($data == 'for'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'forg&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"Select Account.",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Add Account First.",
							'show_alert'=>1
						]);
            }
          } elseif($data == 'selectFollowers'){
            bot('sendMessage',[
                'chat_id'=>$chatId,
                'text'=>'قم بأرسال عدد متابعين .'  
            ]);
            $config['mode'] = 'selectFollowers';
          	$config['mid'] = $mid;
          	file_put_contents('config.json', json_encode($config));
          } elseif($data == 'run'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'start&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"Select Account.",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Add Account First.",
							'show_alert'=>1
						]);
            }
          }elseif($data == 'stop'){
            if(!empty($accounts)){
            $keyboard = [];
             foreach ($accounts as $account => $v) {
                $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'stop&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"Select Account.",
                  'reply_markup'=>json_encode($keyboard)
              ]);
            } else {
              $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Add Account First.",
							'show_alert'=>1
						]);
            }
          }elseif($data == 'stopgr'){
            shell_exec('screen -S gr -X quit');
            $bot->answerCallbackQuery([
							'callback_query_id'=>$update->callback_query->id,
							'text'=>"Done Stop Collecting.",
						// 	'show_alert'=>1
						]);
						$for = $config['for'] != null ? $config['for'] : 'Select Account';
                        $count = count(explode("\n", file_get_contents($for)));
						$bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                        [['text'=>'🔎 سحب من البحث','callback_data'=>'search']],
                        [['text'=>'#⃣ سحب من الهشتاكات','callback_data'=>'hashtag'],['text'=>'📮 سحب من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'👤 سحب من المتابعين','callback_data'=>'followers'],['text'=>"🚹 سحب من المتابعهم",'callback_data'=>'following']],
                        [['text'=>"تحديد حساب ♾ : $for",'callback_data'=>'for']],
                        [['text'=>'🔖 لسته جديده','callback_data'=>'newList'],['text'=>'🖇 لسته قديمة','callback_data'=>'append']],
                        [['text'=>'✅ رجوع','callback_data'=>'back']],
                    ]
                ])
            ]);
          } elseif($data == 'explore'){
            exec('screen -dmS gr php explore.php');
          } elseif($data == 'status'){
					$status = '';
					foreach($accounts as $account => $ac){
						$c = explode(':', $account)[0];
						$x = exec('screen -S '.$c.' -Q select . ; echo $?');
						if($x == '0'){
				        $status .= "*$account* ~> _Working_\n";
				    } else {
				        $status .= "*$account* ~> _Stop_\n";
				    }
					}
					$bot->sendMessage([
							'chat_id'=>$chatId,
							'text'=>"Accounts Status: \n\n $status",
							'parse_mode'=>'markdown'
						]);
				} elseif($data == 'back'){
          	$bot->editMessageText([
                      'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"𝙷𝙸 𝙱𝚁𝙾 𝙸𝙽 𝚃𝙷𝙴 𝙲𝙾𝙽𝚃𝚁𝙾𝙻 𝙱𝚈 ~ @ZZZNZN",
                'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'تسجيل حساب ✨┇','callback_data'=>'login']],
                          [['text'=>'طرق الصيد 🕵️┇','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 📳┇','callback_data'=>'run'],['text'=>'ايقاف الصيد 📴┇','callback_data'=>'stop']],
                          [['text'=>' حاله الحسابات 🪐┇','callback_data'=>'status']],
                      ]
                  ])
               ]);
          } else {
          	$data = explode('&',$data);
          	if($data[0] == 'del'){
          		
          		unset($accounts[$data[1]]);
          		file_put_contents('accounts.json', json_encode($accounts));
              $keyboard = ['inline_keyboard'=>[
							[['text'=>"Add New Accounts",'callback_data'=>'addL']]
									]];
		              foreach ($accounts as $account => $v) {
		                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'ddd'],['text'=>"Logout",'callback_data'=>'del&'.$account]];
		              }
		              $keyboard['inline_keyboard'][] = [['text'=>'🔙 رجوع','callback_data'=>'back']];
		              $bot->editMessageText([
		                  'chat_id'=>$chatId,
		                  'message_id'=>$mid,
		                  'text'=>"Accounts Control Page.",
		                  'reply_markup'=>json_encode($keyboard)
		              ]);
		} elseif($data[0] == 'moveList'){
          	  file_put_contents('list', $data[1]);
          	  $keyboard = [];
          	  foreach ($accounts as $account => $v) {
                  $keyboard['inline_keyboard'][] = [['text'=>$account,'callback_data'=>'moveListTo&'.$account]];
              }
              $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"اختر الحساب الذي تريد نقل اللسته اليه",
                  'reply_markup'=>json_encode($keyboard)
	              ]);
          	} elseif($data[0] == 'moveListTo'){
          	  $keyboard = [];
          	  file_put_contents($data[1], file_get_contents(file_get_contents('list')));
          	  unlink(file_get_contents('list'));
          	  $keyboard['inline_keyboard'][] = [['text'=>'القائمه الرئيسية ✅','callback_data'=>'back']];
          	  $bot->editMessageText([
                  'chat_id'=>$chatId,
                  'message_id'=>$mid,
                  'text'=>"تم نقل اللسته الى الحساب  ✅".$data[1],
                  'reply_markup'=>json_encode($keyboard)
	              ]);
          	} elseif($data[0] == 'forg'){
          	  $config['for'] = $data[1];
          	  file_put_contents('config.json',json_encode($config));
              $for = $config['for'] != null ? $config['for'] : 'Select';
              $count = count(explode("\n", file_get_contents($for)));
              $bot->editMessageText([
                'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"Users collection page. \n - Users : $count \n - For Account : $for",
                'reply_markup'=>json_encode([
                    'inline_keyboard'=>[
                        [['text'=>'🔎 سحب من البحث','callback_data'=>'search']],
                        [['text'=>'📌 سحب من الهشتاكات','callback_data'=>'hashtag'],['text'=>'📮 سحب من الاكسبلور','callback_data'=>'explore']],
                        [['text'=>'👤 سحب من المتابعين','callback_data'=>'followers'],['text'=>"🚹 سحب من المتابعهم",'callback_data'=>'following']],
                        [['text'=>"تحديد حساب ♾ : $for",'callback_data'=>'for']],
                        [['text'=>'🖇 لسته قديمة','callback_data'=>'newList'],['text'=>'🔖 لسته جديده','callback_data'=>'append']],
                        [['text'=>'✅ رجوع','callback_data'=>'back']],
                    ]
                ])
            ]);
          	} elseif($data[0] == 'start'){
          	  file_put_contents('screen', $data[1]);
          	  $bot->editMessageText([
                      'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"𝙷𝙸 𝙱𝚁𝙾 𝙸𝙽 𝚃𝙷𝙴 𝙲𝙾𝙽𝚃𝚁𝙾𝙻 𝙱𝚈 ~ @ZZZNZN",
                'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'تسجيل حساب ✨┇','callback_data'=>'login']],
                          [['text'=>'طرق الصيد 🕵️┇','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 📳┇','callback_data'=>'run'],['text'=>'ايقاف الصيد 📴┇','callback_data'=>'stop']],
                          [['text'=>' حاله الحسابات 🪐┇','callback_data'=>'status']],
                      ]
                  ])
               ]);
              exec('screen -dmS '.explode(':',$data[1])[0].' php start.php');
              $bot->sendMessage([
                'chat_id'=>$chatId,
                'text'=>"🎣 - تم بدأ الصيد 𖡦-› 

الوقت ⏲️ : " . date('g:i') . "\n" . "
الحساب الوهمي 🦇 : ".explode(':',$data[1])[0].'
 ━━━━━━━━━━━━━━━━━━━━━',
                'parse_mode'=>'markdown'
              ]);
          	} elseif($data[0] == 'stop'){
          	  $bot->editMessageText([
                      'chat_id'=>$chatId,
                'message_id'=>$mid,
                'text'=>"𝙷𝙸 𝙱𝚁𝙾 𝙸𝙽 𝚃𝙷𝙴 𝙲𝙾𝙽𝚃𝚁𝙾𝙻 𝙱𝚈 ~ @ZZZNZN",
                'reply_markup'=>json_encode([
                      'inline_keyboard'=>[
                          [['text'=>'تسجيل حساب ✨┇','callback_data'=>'login']],
                          [['text'=>'طرق الصيد 🕵️┇','callback_data'=>'grabber']],
                          [['text'=>'بدء الصيد 📳┇','callback_data'=>'run'],['text'=>'ايقاف الصيد 📴┇','callback_data'=>'stop']],
                          [['text'=>' حاله الحسابات 🪐┇','callback_data'=>'status']],
                      ]
                  ])
               ]);
              exec('screen -S '.explode(':',$data[1])[0].' -X quit');
          	}
          }
			}
		}
	};
	$bot = new EzTG(array('throw_telegram_errors'=>false,'token' => $token, 'callback' => $callback));
} catch(Exception $e){
	echo $e->getMessage().PHP_EOL;
	sleep(1);
}
